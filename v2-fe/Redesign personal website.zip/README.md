
  # Redesign personal website

  This is a code bundle for Redesign personal website. The original project is available at https://www.figma.com/design/84KaDph9mYp2ZTbizFhMvy/Redesign-personal-website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  