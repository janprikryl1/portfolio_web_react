import { motion } from "motion/react";
import { useState } from "react";
import {
  Terminal,
  Code2,
  Database,
  Cloud,
  Mail,
  Github,
  Linkedin,
  ExternalLink,
  ChevronRight,
  Cpu,
  Globe,
  Server,
  GitBranch
} from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState<"skills" | "stack">("skills");

  const techStack = {
    frontend: ["React", "TypeScript", "Next.js", "Tailwind CSS", "Vue.js"],
    backend: ["Python", "Node.js", "Django", "FastAPI", "PostgreSQL"],
    devops: ["Docker", "Kubernetes", "AWS", "GitHub Actions", "Terraform"],
    tools: ["Git", "VS Code", "Figma", "Postman", "Vercel"]
  };

  const projects = [
    {
      id: "01",
      title: "Cloud Infrastructure Platform",
      description: "Distributed system for managing cloud resources across multiple providers",
      tech: ["Python", "Kubernetes", "React", "PostgreSQL"],
      github: "https://github.com",
      demo: null,
      status: "Production"
    },
    {
      id: "02",
      title: "Real-time Analytics Dashboard",
      description: "High-performance data visualization platform processing 1M+ events/day",
      tech: ["TypeScript", "WebSockets", "Redis", "D3.js"],
      github: "https://github.com",
      demo: "https://demo.example.com",
      status: "Active"
    },
    {
      id: "03",
      title: "API Gateway & Service Mesh",
      description: "Microservices architecture with advanced routing and monitoring",
      tech: ["Go", "Docker", "Grafana", "Prometheus"],
      github: "https://github.com",
      demo: null,
      status: "Beta"
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden"
         style={{ fontFamily: 'var(--font-body)' }}>

      {/* Cyber grid background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden opacity-20">
        <div className="absolute inset-0"
             style={{
               backgroundImage: `
                 linear-gradient(rgba(59, 130, 246, 0.1) 1px, transparent 1px),
                 linear-gradient(90deg, rgba(59, 130, 246, 0.1) 1px, transparent 1px)
               `,
               backgroundSize: '50px 50px'
             }}
        />
        <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-secondary/10 rounded-full blur-3xl" />
      </div>

      {/* Navigation */}
      <motion.nav
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="relative z-10 px-6 py-6 lg:px-12 lg:py-8 flex justify-between items-center border-b border-border/50 backdrop-blur-sm bg-background/50"
      >
        <div className="flex items-center gap-2" style={{ fontFamily: 'var(--font-mono)' }}>
          <Terminal className="w-5 h-5 text-primary" />
          <span className="text-sm">~/jan-prikryl</span>
        </div>

        <div className="flex items-center gap-6">
          <a href="#projekty" className="text-sm hover:text-primary transition-colors hidden md:block">
            Projekty
          </a>
          <a href="#stack" className="text-sm hover:text-primary transition-colors hidden md:block">
            Tech Stack
          </a>
          <motion.a
            href="mailto:hello@prikryljan.eu"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-5 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors text-sm"
            style={{ fontFamily: 'var(--font-mono)' }}
          >
            $ contact
          </motion.a>
        </div>
      </motion.nav>

      {/* Hero Section */}
      <section className="relative z-10 px-6 lg:px-12 pt-16 pb-24 lg:pt-32 lg:pb-40">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
          >
            {/* Terminal-like intro */}
            <div className="mb-12 p-6 bg-card border border-primary/20 rounded-lg max-w-2xl"
                 style={{ fontFamily: 'var(--font-mono)' }}>
              <div className="flex items-center gap-2 mb-4 text-muted-foreground text-sm">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-destructive/80" />
                  <div className="w-3 h-3 rounded-full bg-accent/80" />
                  <div className="w-3 h-3 rounded-full bg-primary/80" />
                </div>
                <span>terminal</span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex items-start gap-2">
                  <span className="text-accent">$</span>
                  <span className="text-foreground/70">whoami</span>
                </div>
                <motion.div
                  initial={{ opacity: 0, width: 0 }}
                  animate={{ opacity: 1, width: "auto" }}
                  transition={{ delay: 0.5, duration: 0.8 }}
                  className="text-primary pl-4"
                >
                  Jan Přikryl - Full-Stack Developer
                </motion.div>
                <div className="flex items-start gap-2 mt-4">
                  <span className="text-accent">$</span>
                  <span className="text-foreground/70">cat bio.txt</span>
                </div>
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.3, duration: 0.8 }}
                  className="text-foreground/60 pl-4"
                >
                  Building scalable web applications & distributed systems
                </motion.div>
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.5, duration: 0.5 }}
                  className="flex items-center gap-2 mt-4"
                >
                  <span className="text-accent">$</span>
                  <span className="animate-pulse">_</span>
                </motion.div>
              </div>
            </div>

            <h1
              className="mb-6 leading-[1.1] tracking-tight font-bold"
              style={{
                fontSize: 'clamp(2.5rem, 8vw, 6rem)',
              }}
            >
              Software Engineer<br />
              <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                Full-Stack Developer
              </span>
            </h1>

            <p className="text-lg lg:text-xl text-muted-foreground max-w-2xl mb-10 leading-relaxed">
              Specializuji se na vývoj škálovatelných webových aplikací, mikroservisní architektury
              a cloudových řešení. Zaměřuji se na čistý kód, performance a developer experience.
            </p>

            <div className="flex flex-wrap gap-4">
              <motion.a
                href="#projekty"
                whileHover={{ x: 5 }}
                className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-all group"
                style={{ fontFamily: 'var(--font-mono)' }}
              >
                <span>Prohlédnout projekty</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </motion.a>

              <div className="flex gap-3">
                <motion.a
                  href="https://github.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ y: -3 }}
                  className="w-12 h-12 rounded-lg bg-card border border-border hover:border-primary/50 flex items-center justify-center transition-all"
                >
                  <Github className="w-5 h-5" />
                </motion.a>
                <motion.a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ y: -3 }}
                  className="w-12 h-12 rounded-lg bg-card border border-border hover:border-primary/50 flex items-center justify-center transition-all"
                >
                  <Linkedin className="w-5 h-5" />
                </motion.a>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="relative z-10 px-6 lg:px-12 py-16">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { value: "5+", label: "Let zkušeností", icon: Code2 },
              { value: "50+", label: "Projektů dokončeno", icon: GitBranch },
              { value: "99%", label: "Uptime SLA", icon: Server },
              { value: "15+", label: "Tech stacků", icon: Cpu },
            ].map((stat, index) => {
              const Icon = stat.icon;
              return (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1, duration: 0.5 }}
                  className="p-6 bg-card border border-border rounded-lg hover:border-primary/30 transition-all group"
                >
                  <Icon className="w-6 h-6 text-primary mb-3" />
                  <div className="text-3xl font-bold mb-1" style={{ fontFamily: 'var(--font-mono)' }}>
                    {stat.value}
                  </div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Tech Stack Section */}
      <section id="stack" className="relative z-10 px-6 lg:px-12 py-24 lg:py-32">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="mb-12"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="h-px w-12 bg-primary" />
              <span className="text-sm text-muted-foreground" style={{ fontFamily: 'var(--font-mono)' }}>
                tech_stack.json
              </span>
            </div>
            <h2 className="text-4xl lg:text-5xl font-bold mb-6">
              Technologie & Nástroje
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Object.entries(techStack).map(([category, technologies], catIndex) => (
              <motion.div
                key={category}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ delay: catIndex * 0.1, duration: 0.6 }}
                className="p-6 bg-card border border-border rounded-lg hover:border-primary/30 transition-all"
              >
                <h3 className="text-sm uppercase tracking-wider text-primary mb-4" style={{ fontFamily: 'var(--font-mono)' }}>
                  {category}
                </h3>
                <div className="space-y-2">
                  {technologies.map((tech) => (
                    <div
                      key={tech}
                      className="flex items-center gap-2 text-foreground/80 hover:text-foreground transition-colors text-sm"
                    >
                      <ChevronRight className="w-3 h-3 text-accent" />
                      <span>{tech}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projekty" className="relative z-10 px-6 lg:px-12 py-24 lg:py-32 bg-card/30">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="mb-16"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="h-px w-12 bg-primary" />
              <span className="text-sm text-muted-foreground" style={{ fontFamily: 'var(--font-mono)' }}>
                recent_projects/
              </span>
            </div>
            <h2 className="text-4xl lg:text-5xl font-bold mb-6">
              Vybrané Projekty
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl">
              Přehled nejnovějších projektů s důrazem na škálovatelnost, výkon a clean architecture.
            </p>
          </motion.div>

          <div className="space-y-8">
            {projects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ delay: index * 0.15, duration: 0.6 }}
                className="group relative"
              >
                <div className="p-8 lg:p-10 bg-card border border-border rounded-lg hover:border-primary/40 transition-all hover:shadow-2xl hover:shadow-primary/5">
                  {/* Project header */}
                  <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6 mb-6">
                    <div className="flex-1">
                      <div className="flex items-center gap-4 mb-3">
                        <span className="text-4xl font-bold text-primary/30" style={{ fontFamily: 'var(--font-mono)' }}>
                          {project.id}
                        </span>
                        <span className="px-3 py-1 text-xs bg-accent/20 text-accent rounded-full border border-accent/30" style={{ fontFamily: 'var(--font-mono)' }}>
                          {project.status}
                        </span>
                      </div>

                      <h3 className="text-2xl lg:text-3xl font-bold mb-3 group-hover:text-primary transition-colors">
                        {project.title}
                      </h3>

                      <p className="text-foreground/70 leading-relaxed mb-6">
                        {project.description}
                      </p>

                      <div className="flex flex-wrap gap-2">
                        {project.tech.map((tech) => (
                          <span
                            key={tech}
                            className="px-3 py-1.5 text-xs bg-foreground/5 text-foreground/80 rounded-md border border-border hover:border-primary/30 transition-colors"
                            style={{ fontFamily: 'var(--font-mono)' }}
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="flex lg:flex-col gap-3">
                      <motion.a
                        href={project.github}
                        target="_blank"
                        rel="noopener noreferrer"
                        whileHover={{ scale: 1.05 }}
                        className="flex items-center gap-2 px-4 py-2 bg-foreground/5 hover:bg-primary hover:text-primary-foreground rounded-lg transition-all text-sm"
                        style={{ fontFamily: 'var(--font-mono)' }}
                      >
                        <Github className="w-4 h-4" />
                        <span className="hidden lg:inline">Code</span>
                      </motion.a>

                      {project.demo && (
                        <motion.a
                          href={project.demo}
                          target="_blank"
                          rel="noopener noreferrer"
                          whileHover={{ scale: 1.05 }}
                          className="flex items-center gap-2 px-4 py-2 bg-foreground/5 hover:bg-primary hover:text-primary-foreground rounded-lg transition-all text-sm"
                          style={{ fontFamily: 'var(--font-mono)' }}
                        >
                          <ExternalLink className="w-4 h-4" />
                          <span className="hidden lg:inline">Demo</span>
                        </motion.a>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="relative z-10 px-6 lg:px-12 py-24 lg:py-32">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative p-12 lg:p-16 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 rounded-2xl border border-primary/20 overflow-hidden"
          >
            {/* Background pattern */}
            <div className="absolute inset-0 opacity-10">
              <div className="absolute inset-0"
                   style={{
                     backgroundImage: `
                       linear-gradient(rgba(59, 130, 246, 0.3) 1px, transparent 1px),
                       linear-gradient(90deg, rgba(59, 130, 246, 0.3) 1px, transparent 1px)
                     `,
                     backgroundSize: '30px 30px'
                   }}
              />
            </div>

            <div className="relative z-10 text-center max-w-3xl mx-auto">
              <h2 className="text-4xl lg:text-5xl font-bold mb-6">
                Máte zajímavý projekt?
              </h2>

              <p className="text-xl text-foreground/70 mb-10 leading-relaxed">
                Rád si promluvím o vašem projektu, ať už se jedná o nový startup,
                enterprise aplikaci, nebo open-source spolupráci.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <motion.a
                  href="mailto:hello@prikryljan.eu"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="inline-flex items-center gap-3 px-8 py-4 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-all text-lg group"
                  style={{ fontFamily: 'var(--font-mono)' }}
                >
                  <Mail className="w-5 h-5" />
                  <span>hello@prikryljan.eu</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </motion.a>

                <span className="text-muted-foreground">nebo</span>

                <div className="flex gap-3">
                  <motion.a
                    href="https://github.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    whileHover={{ y: -3 }}
                    className="flex items-center gap-2 px-5 py-3 bg-card border border-border hover:border-primary/50 rounded-lg transition-all"
                    style={{ fontFamily: 'var(--font-mono)' }}
                  >
                    <Github className="w-5 h-5" />
                    <span className="text-sm">GitHub</span>
                  </motion.a>

                  <motion.a
                    href="https://linkedin.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    whileHover={{ y: -3 }}
                    className="flex items-center gap-2 px-5 py-3 bg-card border border-border hover:border-primary/50 rounded-lg transition-all"
                    style={{ fontFamily: 'var(--font-mono)' }}
                  >
                    <Linkedin className="w-5 h-5" />
                    <span className="text-sm">LinkedIn</span>
                  </motion.a>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 px-6 lg:px-12 py-8 border-t border-border/50">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2 text-muted-foreground text-sm" style={{ fontFamily: 'var(--font-mono)' }}>
              <Terminal className="w-4 h-4" />
              <span>© 2026 Jan Přikryl</span>
            </div>

            <div className="flex items-center gap-6">
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-muted-foreground hover:text-primary transition-colors"
                style={{ fontFamily: 'var(--font-mono)' }}
              >
                GitHub
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-muted-foreground hover:text-primary transition-colors"
                style={{ fontFamily: 'var(--font-mono)' }}
              >
                LinkedIn
              </a>
              <a
                href="mailto:hello@prikryljan.eu"
                className="text-sm text-muted-foreground hover:text-primary transition-colors"
                style={{ fontFamily: 'var(--font-mono)' }}
              >
                Email
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}